const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy
const validPassword = require('../lib/passwordUtils').validPassword

const pool = require('./database').pool

const verifyCallback = (username, password, done) => {

    pool.getConnection((err, connection) =>{
        connection.query("SELECT _id,username_hash,_salt FROM UserTable WHERE username = '" + username + "'",(err, data) => {
            connection.release()
            if(!data) return done(null,false)
            const isValid = validPassword(password,)

            if(isValid)return done(null,data)
            else return done(null,false)
        })
    })

    /*
    userSchema.findOne({ username: username })
        .then ((user) => {

            if (!user) { return done(null, false); }
            const isValid = validPassword(password, user.hash, user.salt)

            if(isValid) return done(null, user);
            else return done(null, false);
        })
        .catch((err) => {
            done(err)
        })
    */
}


const strategy = new LocalStrategy({
    usernameField : 'emailreg',
    passwordField : 'passreg',
    passReqToCallback : true
}, verifyCallback);
passport.use(strategy)

passport.serializeUser(function(user, done) {
    done(null, user._id);
});
  
passport.deserializeUser((id, done) => {

    pool.getConnection(function(err, connection) {
        connection.query("SELECT _id,username_hash,_salt FROM UserTable WHERE username = ?", [username],(err, data) => {
            connection.release()
            if(!err) done(null,data[0])
            else done(err)
        })
    })

    /*
    User.findById(userId)
    .then((user) => {
        done(null, user);
    })
    .catch(err => done(err))
    */

});